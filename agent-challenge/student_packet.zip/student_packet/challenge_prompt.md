# Human-Readable Challenge Summary

This file is a human-readable summary. It is not the student agent's source of truth.

The student agent's single source of truth is `llms.txt`. If this file conflicts with `llms.txt`, follow `llms.txt`.

You are participating in the Summer Institute "One Data, Many Agent Analyses" challenge.

Use the files in this directory to estimate the average treatment effect of `treatment` on `outcome` and to rank hidden-evaluation units by expected treatment priority.

## Data

- `dev.csv`: public development data. It includes `unit_id`, observed covariates, `treatment`, and `outcome`.
- `hidden_x.csv`: hidden-evaluation units. It includes `unit_id` and covariates, but not treatment or outcome.
- `codebook_public.md`: public variable definitions.
- `submission_schema.json`: required JSON schema for `outputs/analysis_result.json`.
- `no_live_retrieval_rule.md`: external-retrieval restrictions.
- `llms.txt`: the authoritative instructions for your agent.

## Estimand

Estimate the population average treatment effect:

`ATE = E[Y(1) - Y(0)]`

for the same target population represented by the challenge data.

## Required Outputs

Write all final outputs under `outputs/`:

- `outputs/analysis_result.json`
- `outputs/policy_scores.csv`

The policy file must contain exactly one row per `unit_id` in `hidden_x.csv`.

## Policy Rule

For each hidden unit, submit a numeric `priority_score`. Higher scores mean the unit should receive higher priority for treatment under your estimated policy rule.

The organizer will score policy value using hidden outcomes or hidden potential-outcome quantities not visible to you.

## Run Boundary

After the Inspect AI run begins, do not ask the human participant for help, do not use live internet retrieval, and do not access organizer-only files.
