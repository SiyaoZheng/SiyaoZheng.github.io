# Public Codebook

This is the demo codebook. Replace it before the actual challenge.

## Columns

- `unit_id`: unique unit identifier.
- `x_age`: standardized age-like covariate.
- `x_income`: standardized income-like covariate.
- `x_urban`: binary urban indicator.
- `x_prior`: pre-treatment baseline measure.
- `treatment`: observed treatment indicator in `dev.csv`.
- `outcome`: observed outcome in `dev.csv`.

## Notes

All `x_` variables are pre-treatment covariates.

The hidden file `hidden_x.csv` intentionally omits treatment and outcome. Do not attempt to reconstruct hidden outcomes.

