# No Live External Retrieval Rule

During the challenge run, the agent may read local files in the challenge directory and execute local analysis code.

The agent must not use:

- web search
- browser browsing
- live package documentation lookup
- external APIs
- remote databases
- social media or news sites
- hidden organizer files

Installed local packages may be used. If a package is unavailable, the agent should choose another local method rather than using the internet.

The required attestation in `outputs/analysis_result.json` must be `true` only if this rule was followed.

