#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


REQUIRED_FILES = [
    Path("outputs/analysis_result.json"),
    Path("outputs/policy_scores.csv"),
]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Package a challenge submission.")
    parser.add_argument("--participant-id", required=True)
    parser.add_argument("--output", default=None, help="Output zip path.")
    args = parser.parse_args()

    missing = [str(path) for path in REQUIRED_FILES if not path.exists()]
    if missing:
        raise SystemExit(f"Missing required files: {', '.join(missing)}")

    output = Path(args.output or f"submission_{args.participant_id}.zip")
    manifest = {
        "participant_id": args.participant_id,
        "packaged_at": datetime.now(timezone.utc).isoformat(),
        "files": {},
    }

    candidate_files = list(REQUIRED_FILES)
    for optional in [Path("trace.jsonl"), Path("outputs/trace.jsonl"), Path("outputs/workspace_snapshot.zip")]:
        if optional.exists():
            candidate_files.append(optional)

    with ZipFile(output, "w", compression=ZIP_DEFLATED) as archive:
        for path in candidate_files:
            archive.write(path, path.as_posix())
            manifest["files"][path.as_posix()] = {
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        archive.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False))

    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

