# 0611 Talk: 研究者的智能体操作系统

这个目录是 6 月 11 日讲座的演示材料和 Python 环境。讲座主题从“从聊天机器人到智能体的社会科学研究工作流转型”升级为“研究者的智能体操作系统”：把社会科学项目重新组织成可被智能体读取、运行、审计和展示的 AI-native social science lab。讲座前半部分主要讲技术原理，并坚持示例驱动：用当前 WDI 项目展示 agent loop、tool calling / MCP、skill、project contract、sandbox / code execution、memory / provenance 与 eval / red team 如何共同构成研究智能体工作流。

## 讲座摘要

本讲座围绕“研究者的智能体操作系统”展开，面向希望将人工智能真正嵌入科研生产的社会科学研究者。讲座前半部分将以示例驱动的方式讲解智能体的关键技术原理：agent loop 如何把模型转化为可行动系统，tool calling 与 MCP 如何把外部数据、文件、浏览器和统计软件变成可调用接口，skill 如何把研究者的经验转化为可触发、可复用、可版本化的操作规程，project contract、sandbox、memory、provenance 与 eval/red team 又如何共同构成可审计的研究环境。讲座后半部分将结合一个公开真实经济数据的 mini research lab，展示如何用自然语言启动一个可审计的研究项目：下载 World Bank WDI 数据、保留原始 API 返回、整理国家-年份面板、生成图表和模型摘要、记录数据来源，并用 `make verify` 做自动核查。重点不在于把人工智能包装成替代研究者的“自动科学家”，而是帮助研究者从“问 AI 要答案”升级为“组织一个受约束、可复现、可核查、可迭代的智能体实验室”。

## 前半部分技术主线

| 原理 | 当前目录中的示例 |
|---|---|
| Agent loop | 让智能体读取项目、制定计划、执行命令、核查输出 |
| Tool calling / MCP | 用 `scripts/fetch_wdi.py` 调用 World Bank API |
| Skill | 用伪 skill 展示触发条件、操作步骤、失败条件和输出标准 |
| Project contract | 用 README、Makefile、data/outputs 结构展示 agent-readable project |
| Sandbox / code execution | 用 `.venv`、`make all`、`make verify` 展示可控运行 |
| Memory / provenance | 用 `metadata/data_provenance.json` 展示证据账本 |
| Eval / red team | 让 reviewer agent 检查 OLS 是否被误读为因果结论 |

## 现场演示案例

演示数据来自 World Bank World Development Indicators (WDI) API，均为公开真实数据，不需要 API key。案例会展示一个完整的小型研究工作流：

1. 明确演示任务和数据来源。
2. 下载真实公开数据并保存原始 API 返回。
3. 将长表整理成国家-年份面板数据。
4. 生成描述性图表和简单 OLS 模型摘要。
5. 记录 provenance、输出路径和可复现命令。

## 快速使用

```bash
cd /Users/siyaozheng/Documents/教学/talks/0611talk
source .venv/bin/activate
make demo
```

如果需要从零搭环境：

```bash
cd /Users/siyaozheng/Documents/教学/talks/0611talk
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/pip install -r requirements.txt
make all
```

## 数据内容

国家样本：

- China, United States, India, Japan, Germany
- Korea, Rep., Vietnam, Brazil, South Africa, Mexico

指标：

- GDP per capita, constant 2015 US$
- GDP growth, annual %
- Inflation, consumer prices, annual %
- Trade, % of GDP
- Unemployment, total, % of total labor force
- Population, total

时间范围：1990-2025。实际可用年份由 World Bank API 返回的数据决定。

## 文件结构

```text
0611talk/
  data/raw/worldbank_api/          # World Bank API 原始 JSON
  data/raw/wdi_selected_long.csv   # API 记录整理成长表
  data/processed/wdi_economics_panel.csv
  data/processed/latest_country_snapshot.csv
  metadata/data_provenance.json
  outputs/demo_summary.md
  outputs/model_summary.txt
  outputs/figures/
  talk_brief.md
  detailed_outline.md
  scripts/fetch_wdi.py
  scripts/demo_analysis.py
```

## 复现命令

```bash
make data      # 重新下载 WDI 数据并生成 processed CSV
make demo      # 用 processed CSV 生成图表和 OLS 摘要
make verify    # 检查配置能否加载、数据和输出是否存在
```

## Provenance

官方 API：

- https://api.worldbank.org/v2/
- https://data.worldbank.org/

本目录的 `metadata/data_provenance.json` 会记录实际下载时间、API URL、指标、国家和行数。课堂展示时，把这里当作数据来源说明的主证据。

## 前沿锚点

- MCP: https://modelcontextprotocol.io/docs/getting-started/intro
- OpenAI Agents SDK 2026 harness and sandbox update: https://openai.com/index/the-next-evolution-of-the-agents-sdk/
- OpenAI Deep Research: https://openai.com/index/introducing-deep-research/
- PROV-AGENT: https://arxiv.org/abs/2508.02866
- MCP-native AI scientist ecosystems: https://www.frontiersin.org/journals/artificial-intelligence/articles/10.3389/frai.2026.1820375/full

## 教学提示

这个演示适合讲四件事：

1. 真实公开数据如何从 API 到可分析面板数据。
2. 同一经济指标在国家和年份之间的可比性边界。
3. 简单回归输出如何用于演示模型工作流，而不是直接当作因果结论。
4. 智能体输出必须留下可检查的数据、代码、日志和 provenance，而不能只停留在回答文本。
