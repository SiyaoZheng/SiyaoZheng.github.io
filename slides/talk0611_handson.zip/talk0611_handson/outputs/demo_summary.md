# 0611talk demo summary

Data source: World Bank World Development Indicators API.

Downloaded at UTC: `2026-06-09T09:04:04.781609+00:00`

Panel shape:

- Rows: 360
- Countries: 10
- Requested years: 1990-2025
- Regression demo rows after complete-case filtering: 250

Latest complete year by country:

- BRA: 2024
- CHN: 2024
- DEU: 2024
- IND: 2024
- JPN: 2024
- KOR: 2024
- MEX: 2024
- USA: 2024
- VNM: 2024
- ZAF: 2024

Generated figures:

- `outputs/figures/gdp_per_capita_trajectories.png`
- `outputs/figures/latest_trade_growth.png`

Model note:

The OLS model is for workflow demonstration only. It controls for country and year indicators, but it is not a causal design.
