#!/usr/bin/env python3
"""Create classroom-ready figures and a small OLS demo from the WDI panel."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import statsmodels.formula.api as smf


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PANEL_PATH = PROJECT_ROOT / "data" / "processed" / "wdi_economics_panel.csv"
SNAPSHOT_PATH = PROJECT_ROOT / "data" / "processed" / "latest_country_snapshot.csv"
PROVENANCE_PATH = PROJECT_ROOT / "metadata" / "data_provenance.json"
FIG_DIR = PROJECT_ROOT / "outputs" / "figures"
SUMMARY_PATH = PROJECT_ROOT / "outputs" / "demo_summary.md"
MODEL_SUMMARY_PATH = PROJECT_ROOT / "outputs" / "model_summary.txt"


def load_data() -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    panel = pd.read_csv(PANEL_PATH)
    snapshot = pd.read_csv(SNAPSHOT_PATH)
    provenance = json.loads(PROVENANCE_PATH.read_text())
    return panel, snapshot, provenance


def plot_gdp_trajectories(panel: pd.DataFrame) -> None:
    plot_df = panel.dropna(subset=["gdp_pc_constant_2015_usd"]).copy()
    plt.figure(figsize=(11, 6.2))
    sns.lineplot(
        data=plot_df,
        x="year",
        y="gdp_pc_constant_2015_usd",
        hue="country_code",
        linewidth=2,
    )
    plt.yscale("log")
    plt.title("GDP per capita trajectories, 1990-latest")
    plt.xlabel("Year")
    plt.ylabel("GDP per capita, constant 2015 US$ (log scale)")
    plt.legend(title="Country", ncol=2, frameon=False)
    plt.tight_layout()
    plt.savefig(FIG_DIR / "gdp_per_capita_trajectories.png", dpi=180)
    plt.close()


def plot_latest_trade_growth(snapshot: pd.DataFrame) -> None:
    plot_df = snapshot.dropna(subset=["trade_pct_gdp", "gdp_growth_annual_pct", "population"]).copy()
    plot_df["population_millions"] = plot_df["population"] / 1_000_000

    plt.figure(figsize=(10.5, 6.2))
    ax = sns.scatterplot(
        data=plot_df,
        x="trade_pct_gdp",
        y="gdp_growth_annual_pct",
        size="population_millions",
        sizes=(80, 900),
        hue="country_code",
        legend=False,
        alpha=0.78,
    )
    for _, row in plot_df.iterrows():
        ax.annotate(row["country_code"], (row["trade_pct_gdp"], row["gdp_growth_annual_pct"]), xytext=(5, 4), textcoords="offset points")
    plt.axhline(0, color="#777777", linewidth=0.8)
    plt.title("Latest complete year: trade openness and GDP growth")
    plt.xlabel("Trade (% of GDP)")
    plt.ylabel("GDP growth (annual %)")
    plt.tight_layout()
    plt.savefig(FIG_DIR / "latest_trade_growth.png", dpi=180)
    plt.close()


def run_regression(panel: pd.DataFrame) -> tuple[str, pd.DataFrame]:
    model_df = panel.query("year >= 2000").dropna(
        subset=[
            "gdp_growth_annual_pct",
            "log_gdp_pc",
            "inflation_annual_pct",
            "trade_pct_gdp",
            "unemployment_pct",
        ]
    )
    formula = (
        "gdp_growth_annual_pct ~ log_gdp_pc + inflation_annual_pct "
        "+ trade_pct_gdp + unemployment_pct + C(country_code) + C(year)"
    )
    model = smf.ols(formula=formula, data=model_df).fit(cov_type="HC1")
    return model.summary().as_text(), model_df


def write_summary(panel: pd.DataFrame, snapshot: pd.DataFrame, provenance: dict, model_df: pd.DataFrame) -> None:
    years = sorted(panel["year"].dropna().astype(int).unique())
    latest_years = snapshot[["country_code", "year"]].sort_values("country_code")
    latest_lines = "\n".join(
        f"- {row.country_code}: {int(row.year)}"
        for row in latest_years.itertuples(index=False)
    )

    body = f"""# 0611talk demo summary

Data source: World Bank World Development Indicators API.

Downloaded at UTC: `{provenance.get("downloaded_at_utc")}`

Panel shape:

- Rows: {len(panel)}
- Countries: {panel["country_code"].nunique()}
- Requested years: {years[0]}-{years[-1]}
- Regression demo rows after complete-case filtering: {len(model_df)}

Latest complete year by country:

{latest_lines}

Generated figures:

- `outputs/figures/gdp_per_capita_trajectories.png`
- `outputs/figures/latest_trade_growth.png`

Model note:

The OLS model is for workflow demonstration only. It controls for country and year indicators, but it is not a causal design.
"""
    SUMMARY_PATH.write_text(body)


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    SUMMARY_PATH.parent.mkdir(parents=True, exist_ok=True)

    panel, snapshot, provenance = load_data()
    plot_gdp_trajectories(panel)
    plot_latest_trade_growth(snapshot)
    model_summary, model_df = run_regression(panel)
    MODEL_SUMMARY_PATH.write_text(model_summary)
    write_summary(panel, snapshot, provenance, model_df)

    print(f"Wrote {FIG_DIR / 'gdp_per_capita_trajectories.png'}")
    print(f"Wrote {FIG_DIR / 'latest_trade_growth.png'}")
    print(f"Wrote {SUMMARY_PATH}")
    print(f"Wrote {MODEL_SUMMARY_PATH}")


if __name__ == "__main__":
    main()

