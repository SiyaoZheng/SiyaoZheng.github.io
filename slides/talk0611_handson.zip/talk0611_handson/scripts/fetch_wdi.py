#!/usr/bin/env python3
"""Download a compact economics demo panel from the World Bank WDI API."""

from __future__ import annotations

import json
import math
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import requests


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RAW_API_DIR = PROJECT_ROOT / "data" / "raw" / "worldbank_api"
RAW_LONG_PATH = PROJECT_ROOT / "data" / "raw" / "wdi_selected_long.csv"
PROCESSED_PANEL_PATH = PROJECT_ROOT / "data" / "processed" / "wdi_economics_panel.csv"
LATEST_SNAPSHOT_PATH = PROJECT_ROOT / "data" / "processed" / "latest_country_snapshot.csv"
PROVENANCE_PATH = PROJECT_ROOT / "metadata" / "data_provenance.json"

BASE_URL = "https://api.worldbank.org/v2"
DATE_RANGE = "1990:2025"
PER_PAGE = 20000

COUNTRIES = {
    "CHN": "China",
    "USA": "United States",
    "IND": "India",
    "JPN": "Japan",
    "DEU": "Germany",
    "KOR": "Korea, Rep.",
    "VNM": "Vietnam",
    "BRA": "Brazil",
    "ZAF": "South Africa",
    "MEX": "Mexico",
}

INDICATORS = {
    "NY.GDP.PCAP.KD": {
        "column": "gdp_pc_constant_2015_usd",
        "label": "GDP per capita (constant 2015 US$)",
    },
    "NY.GDP.MKTP.KD.ZG": {
        "column": "gdp_growth_annual_pct",
        "label": "GDP growth (annual %)",
    },
    "FP.CPI.TOTL.ZG": {
        "column": "inflation_annual_pct",
        "label": "Inflation, consumer prices (annual %)",
    },
    "NE.TRD.GNFS.ZS": {
        "column": "trade_pct_gdp",
        "label": "Trade (% of GDP)",
    },
    "SL.UEM.TOTL.ZS": {
        "column": "unemployment_pct",
        "label": "Unemployment, total (% of total labor force)",
    },
    "SP.POP.TOTL": {
        "column": "population",
        "label": "Population, total",
    },
}


def fetch_indicator(session: requests.Session, indicator: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    country_path = ";".join(COUNTRIES)
    params = {
        "format": "json",
        "per_page": PER_PAGE,
        "date": DATE_RANGE,
        "page": 1,
    }
    all_rows: list[dict[str, Any]] = []
    pages: list[Any] = []

    while True:
        url = f"{BASE_URL}/country/{country_path}/indicator/{indicator}"
        response = session.get(url, params=params, timeout=30)
        response.raise_for_status()
        payload = response.json()
        pages.append(payload)
        if not isinstance(payload, list) or len(payload) < 2:
            raise RuntimeError(f"Unexpected World Bank response for {indicator}: {payload!r}")

        meta, rows = payload[0], payload[1] or []
        all_rows.extend(rows)

        if int(meta.get("page", 1)) >= int(meta.get("pages", 1)):
            raw_path = RAW_API_DIR / f"{indicator}.json"
            raw_path.write_text(json.dumps(pages, ensure_ascii=False, indent=2) + "\n")
            return all_rows, meta

        params["page"] = int(params["page"]) + 1
        time.sleep(0.2)


def normalize_rows(indicator: str, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    info = INDICATORS[indicator]
    normalized: list[dict[str, Any]] = []
    for row in rows:
        country = row.get("country") or {}
        indicator_info = row.get("indicator") or {}
        normalized.append(
            {
                "country_code": row.get("countryiso3code"),
                "country": country.get("value"),
                "year": int(row["date"]),
                "indicator_id": indicator_info.get("id", indicator),
                "indicator_name": indicator_info.get("value", info["label"]),
                "indicator_column": info["column"],
                "value": row.get("value"),
                "obs_status": row.get("obs_status"),
                "decimal": row.get("decimal"),
            }
        )
    return normalized


def build_panel(long_df: pd.DataFrame) -> pd.DataFrame:
    panel = (
        long_df.pivot_table(
            index=["country_code", "country", "year"],
            columns="indicator_column",
            values="value",
            aggfunc="first",
        )
        .reset_index()
        .sort_values(["country_code", "year"])
    )
    panel.columns.name = None

    for column in INDICATORS.values():
        col = column["column"]
        if col not in panel:
            panel[col] = pd.NA

    panel["log_gdp_pc"] = pd.NA
    mask = panel["gdp_pc_constant_2015_usd"].notna() & (panel["gdp_pc_constant_2015_usd"] > 0)
    panel.loc[mask, "log_gdp_pc"] = panel.loc[mask, "gdp_pc_constant_2015_usd"].apply(math.log)

    ordered_columns = [
        "country_code",
        "country",
        "year",
        "gdp_pc_constant_2015_usd",
        "log_gdp_pc",
        "gdp_growth_annual_pct",
        "inflation_annual_pct",
        "trade_pct_gdp",
        "unemployment_pct",
        "population",
    ]
    return panel[ordered_columns]


def latest_complete_snapshot(panel: pd.DataFrame) -> pd.DataFrame:
    core = [
        "gdp_pc_constant_2015_usd",
        "gdp_growth_annual_pct",
        "inflation_annual_pct",
        "trade_pct_gdp",
        "unemployment_pct",
        "population",
    ]
    complete = panel.dropna(subset=core)
    return (
        complete.sort_values(["country_code", "year"])
        .groupby("country_code", as_index=False)
        .tail(1)
        .sort_values("country_code")
    )


def main() -> None:
    for path in [
        RAW_API_DIR,
        RAW_LONG_PATH.parent,
        PROCESSED_PANEL_PATH.parent,
        PROVENANCE_PATH.parent,
    ]:
        path.mkdir(parents=True, exist_ok=True)

    session = requests.Session()
    normalized_rows: list[dict[str, Any]] = []
    api_meta: dict[str, Any] = {}
    urls: dict[str, str] = {}

    for indicator in INDICATORS:
        rows, meta = fetch_indicator(session, indicator)
        normalized_rows.extend(normalize_rows(indicator, rows))
        api_meta[indicator] = meta
        urls[indicator] = (
            f"{BASE_URL}/country/{';'.join(COUNTRIES)}/indicator/{indicator}"
            f"?format=json&per_page={PER_PAGE}&date={DATE_RANGE}"
        )

    long_df = pd.DataFrame(normalized_rows)
    long_df["value"] = pd.to_numeric(long_df["value"], errors="coerce")
    long_df.to_csv(RAW_LONG_PATH, index=False)

    panel = build_panel(long_df)
    panel.to_csv(PROCESSED_PANEL_PATH, index=False)

    snapshot = latest_complete_snapshot(panel)
    snapshot.to_csv(LATEST_SNAPSHOT_PATH, index=False)

    provenance = {
        "source": "World Bank World Development Indicators API",
        "source_homepage": "https://data.worldbank.org/",
        "api_base": BASE_URL,
        "downloaded_at_utc": datetime.now(timezone.utc).isoformat(),
        "date_range_requested": DATE_RANGE,
        "countries": COUNTRIES,
        "indicators": INDICATORS,
        "api_urls": urls,
        "api_meta": api_meta,
        "row_counts": {
            "raw_long": int(len(long_df)),
            "processed_panel": int(len(panel)),
            "latest_snapshot": int(len(snapshot)),
        },
    }
    PROVENANCE_PATH.write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + "\n")

    print(f"Wrote {RAW_LONG_PATH.relative_to(PROJECT_ROOT)} ({len(long_df)} rows)")
    print(f"Wrote {PROCESSED_PANEL_PATH.relative_to(PROJECT_ROOT)} ({len(panel)} rows)")
    print(f"Wrote {LATEST_SNAPSHOT_PATH.relative_to(PROJECT_ROOT)} ({len(snapshot)} rows)")
    print(f"Wrote {PROVENANCE_PATH.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
